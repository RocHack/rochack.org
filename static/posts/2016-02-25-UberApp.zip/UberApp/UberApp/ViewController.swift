//
//  ViewController.swift
//  UberApp
//
//  Created by Dan Hassin on 2/25/16.
//  Copyright © 2016 Dan Hassin. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {
	
	// The "@IBOutlet" here means it'll be connected to a user interface element
	@IBOutlet var textField : UITextField!
	let locationManager = CLLocationManager()

	override func viewDidLoad()
	{
		super.viewDidLoad()
		
		// Need to first request authorization from the user
		locationManager.requestWhenInUseAuthorization()
		
		// Start updating location!
		locationManager.startUpdatingLocation()
	}
	
	// This function is called whenever the map finds a new user location.
	// Center the map to show 200 meters around the user location (otherwise it's way
	// too zoomed out!)
	func mapView(mapView: MKMapView, didUpdateUserLocation userLocation: MKUserLocation)
	{
		let region = MKCoordinateRegionMakeWithDistance(mapView.userLocation.coordinate, 200, 200)
		mapView.setRegion(region, animated: true)
	}
	
	// This function is called whenever the user scrolls around the map
	// Here we want to update the address bar to whatever the user selects
	func mapView(mapView: MKMapView, regionDidChangeAnimated animated: Bool)
	{
		// Location of the center of the map
		let location = CLLocation(latitude:  mapView.centerCoordinate.latitude, longitude:  mapView.centerCoordinate.longitude)
		
		// Reverse-geocoding means taking lat/long and converting it into an address
		// This requires an internet connection and could take time, so it's asynchronous,
		// i.e. it happens in the background. When it's done, it'll call the block we give it
		CLGeocoder().reverseGeocodeLocation(location) { (p : [CLPlacemark]?, e: NSError?) -> Void in
			
			// Take the first result
			let placemark = p![0]
			
			// This is how you string-interpolate in Swift. Ignore the ?? for now :)
			self.textField.text = "\(placemark.subThoroughfare ?? "") \(placemark.thoroughfare ?? ""), \(placemark.subAdministrativeArea ?? "")"
			
		}

	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

